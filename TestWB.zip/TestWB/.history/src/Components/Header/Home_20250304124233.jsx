import React from 'react'

export const Home = () => {
  return (
    <div className='w-[100vw]'>

    </div>
  )
}

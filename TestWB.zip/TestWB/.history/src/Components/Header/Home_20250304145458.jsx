import React from 'react'
import { MainCompo } from '../MainCompo/MainCompo'

export const Home = () => {
  return (
    <>
    <MainCompo>
      hello
    </MainCompo>
    </>
  )
}

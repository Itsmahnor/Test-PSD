import React from 'react'

export const Home = () => {
  return (
    <div>
      
    </div>
  )
}
